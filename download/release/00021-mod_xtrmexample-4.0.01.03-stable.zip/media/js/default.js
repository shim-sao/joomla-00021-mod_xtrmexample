// Default Module XtrmAddons Example javascript
// Put the code here :